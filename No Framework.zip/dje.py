import time

def binary_heartbeat(name):
    morse_code = {
        'H': '....', 'A': '.-', 'P': '.--.', 'Y': '-.--',
        'B': '-...', 'I': '..', 'R': '.-.', 'T': '-', 'D': '-..'
    }
    message = "".join([morse_code[char] for char in "HAPPYBIRTHDAY" if char in morse_code])
    
    for bit in message:
        heart = "❤️" if bit == '.' else "💓"
        print(f"\n{heart * 3}\nBINARY LOVE FOR {name.upper()}\n{heart * 3}", end="\r")
        time.sleep(0.5)
    print("\n\n(>^.^<) You're my 0x1 bestie!")

binary_heartbeat("Bestie's Name")